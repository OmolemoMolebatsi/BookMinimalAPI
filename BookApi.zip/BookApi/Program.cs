using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<DataContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));


var app = builder.Build();

// Configure the HTTP request pipelin
//add swagger as well
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

///TO VIEW THE BOOKS
app.MapGet("/books", async (DataContext Context) =>
    await Context.Books.ToListAsync());

//view book by id number
app.MapGet("/books/{id}", async (int id, DataContext Context) =>
    await Context.Books.FindAsync(id) is Book book ? 
    Results.Ok(book) : Results.NotFound("This Book doesn't exist  :("));

///ADD A BOOK
app.MapPost("/books", async (Book book, DataContext Context) =>
{
    Context.Books.Add(book);
    await Context.SaveChangesAsync();
    return Results.Created($"/books/{book.Id}", book);
});

///EDIT A BOOK- edit book details- id,title,author,year and isbn

app.MapPut("/books/{id}", async (int id, Book input, DataContext Context) =>
{
    var book = await Context.Books.FindAsync(id);
    if (book is null) return Results.NotFound();

    book.Title = input.Title;
    book.Author = input.Author;
    book.Year = input.Year;
    book.ISBN = input.ISBN;


    await Context.SaveChangesAsync();
    return Results.Ok("Book successfully edited");
});


///DELE A BOOK --book details- id,title,author,year and isbn
app.MapDelete("/books/{id}", async (int id, DataContext Context) =>
{
    var book = await Context.Books.FindAsync(id);
    if (book is null) return Results.NotFound();

    Context.Books.Remove(book);
    await Context.SaveChangesAsync();
    return Results.Ok("Book successfully deleted :)");
});
;

app.Run();


//BOOK CLASS with model items,what's the data being used
public class Book {
    public int Id { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    public int Year { get; set; }
    public string ISBN { get; set; }

}

//data context for the database
public class DataContext : DbContext
{
    public DataContext(DbContextOptions<DataContext> options) : base(options) { }

    public DbSet<Book> Books => Set<Book>();


}